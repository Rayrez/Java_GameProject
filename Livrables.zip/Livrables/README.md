﻿# JPU-BlankProject

This project has been realized by 4 people:
Pierre Garrido, Bastien Aelters, Benjamin Brifault, Mattias Hurot.

Distribution of project tasks:

Pierre Garrido:
- Creation of packages content "model", "entity" and "view" in java.
- Creation of tests to "model" and "entity".
- Creation of Javadoc.

Bastien Aelters:
- Creation of packages content "view" and "controller" in java.
- Creation of tests to "view".
- Creation of Javadoc.

Benjamin Brifault:
- Creation of packages content "view" and "controller" in java.
- Modification of diagrams (class, packages, components).
- Creation of Javadoc.

Mattias Huros:
- Creation of packages content "controller" in java.
- Creation of tests to "controller".
- Creation of Javadoc.